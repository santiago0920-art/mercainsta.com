﻿
using Dapper;
using mercainsta.com.Models;
using Microsoft.Data.SqlClient;

namespace mercainsta.com.servicios
{
    public interface Irepositorioregistro
    {
        Task<bool> registromodel(registromodel guardar);
    }

    public class repositorioregistro : Irepositorioregistro
    {

        private readonly string cnx;
        public repositorioregistro(IConfiguration configuration)
        {
            cnx = configuration.GetConnectionString("Defaultconnetion");

        }
        public async Task<bool> registromodel(registromodel guardar)
        {
            using var connetion = new SqlConnection(cnx);

            bool isInserted = await connetion.ExecuteAsync(

                     @"INSERT INTO Registro_usuario (Id,nombre,apellido,sexo,correo,contraseña,Cconfirmar)
                    VALUES (@Id,@nombre,@apellido,@sexo,@correo,@contraseña,@Cconfirmar)", guardar) > 0;



            return isInserted;



        }



    }







}








