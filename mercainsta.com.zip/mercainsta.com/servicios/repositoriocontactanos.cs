﻿namespace mercainsta.com.servicios
{
    public class repositoriocontactanos
    {
    }
}
