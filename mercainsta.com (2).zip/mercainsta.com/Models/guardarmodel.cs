﻿namespace mercainsta.com.Models
{
    public class guardarmodel
    {
        public string codigo { get; set; }
        public string descripcion { get; set; }
        public string cantidad { get; set; }

        public string valor { get; set; }













    }
}
