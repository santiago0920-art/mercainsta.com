﻿namespace mercainsta.com.Models
{
    public class recuperarmodel
    {
        public string Nidentidad{get; set;}

        public string correo{get; set;}
    }
}

















