﻿namespace mercainsta.com.Models
{
    public class provedormodel
    {
        public string idproducto { get; set; }

        public string idpersona { get; set; }

        public string NyA { get; set; }

        public string cantidad { get; set; }

        public string  precio { get; set; }


    }
}
