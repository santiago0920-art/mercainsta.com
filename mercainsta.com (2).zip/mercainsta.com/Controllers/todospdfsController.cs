﻿using Microsoft.AspNetCore.Mvc;

namespace mercainsta.com.Controllers
{
    public class todospdfsController : Controller
    {
       public IActionResult todospdf()
        {

            return View();
        }
    }
}
